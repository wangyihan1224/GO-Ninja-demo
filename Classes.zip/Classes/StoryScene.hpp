//
//  StoryScene.hpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/18.
//
//

#ifndef StoryScene_hpp
#define StoryScene_hpp
#include "LoadScene/LoadingScene.hpp"
#include <stdio.h>
#include "cocos2d.h"
#include "ui/CocosGui.h"
#include "cocostudio/CocoStudio.h"
#include "LineFeed.hpp"
USING_NS_CC;
using namespace ui;
class StoryScene:public Scene{
public:
    CREATE_FUNC(StoryScene);
    bool init();
  virtual  void onEnterTransitionDidFinish();
private:
    Node*_fristLayer;
    Node*_secondLayer;
    Node*_thirdLayer;
    Node*_fourthLayer;
    Node*_fifthLayer;
    Vector<LineFeed*> _lineFees;
    
    void showFirstLayer();
    void showSecondLayer();
    void showThirdLayer();
    void showFourthLayer();
    void showFiveLayer();
};
#endif /* StoryScene_hpp */
