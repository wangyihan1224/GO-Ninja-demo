//
//  Enemy.h
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/22.
//
//

#ifndef Enemy_h
#define Enemy_h
#include "RoleAnimationData.h"
class Enemy{

public
    :
    int harm;
    RoleAnimationData standAnim;
    RoleAnimationData willDieAnim;
    

};

#endif /* Enemy_h */
