//
//  HeroData.h
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/22.
//
//

#ifndef HeroData_h
#define HeroData_h
#include "RoleAnimationData.h"
#include "cocos2d.h"
class HeroData{
public:
    float speed;
    int jumpTime;
    float jumpHeight;
    float coefficient;
    RoleAnimationData runAnim;
    RoleAnimationData jumpAnim;
    RoleAnimationData jumpDownAnim;
    RoleAnimationData attackAnim;
    RoleAnimationData willDieAnim;
    RoleAnimationData dustAnim;
};

#endif /* HeroData_h */
