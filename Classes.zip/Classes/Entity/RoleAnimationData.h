//
//  RoleAnimationData.h
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/22.
//
//

#ifndef RoleAnimationData_h
#define RoleAnimationData_h
#include "cocos2d.h"
USING_NS_CC;
class RoleAnimationData{

public:
    std::string animName;
    Vec2 anchorPoint;
    Vec2 collisionStartPos;
    Size collisionSize;
};
#endif /* RoleAnimationData_h */
