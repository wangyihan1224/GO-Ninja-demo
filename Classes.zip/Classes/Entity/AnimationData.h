//
//  AnimationData.h
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/21.
//
//

#ifndef AnimationData_h
#define AnimationData_h
#include "cocos2d.h"

#include <stdio.h>
USING_NS_CC;
class AnimationData {
public:
    std::string animationKey;
    std::string fileName;
    int row;
    int col;
    int startIndex;
    int stopIndex;
    int loop;
    float delayPerUnit;

};
#endif /* AnimationData_h */
