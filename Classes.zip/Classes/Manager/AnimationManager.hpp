//
//  AnimationManager.hpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/21.
//
//

#ifndef AnimationManager_hpp
#define AnimationManager_hpp

#include <stdio.h>
#include "cocos2d.h"
#include "AnimationData.h"
#include "DataManager.hpp"
USING_NS_CC;

class AnimationManager:public Ref{

public:
    
    static AnimationManager*getInstance();
    void init();
    Animation*getAnimationFromCache(const std::string &name);
    
private:
    Animation* createAnimation(AnimationData data);
    Animation* createAnimation(const char* fileName,int row,int col,int startIndex,int stopIndex,float delayPerunit,int loop);
};
#endif /* AnimationManager_hpp */
