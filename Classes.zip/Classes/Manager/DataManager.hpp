//
//  DataManager.hpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/21.
//
//

#ifndef DataManager_hpp
#define DataManager_hpp
#include "cocos2d.h"
#include <stdio.h>
#include "AnimationData.h"
#include "RoleAnimationData.h"
#include "HeroData.h"
#include "Enemy.h"
USING_NS_CC;
class DataManager:public Ref{
public:
    
    static DataManager*getInstance();
    void init();
    CC_SYNTHESIZE_READONLY(ValueMap, _animationMap, AnimationMap);
    AnimationData getAnimationDataWithName(const std::string &name);
    CC_SYNTHESIZE_READONLY(ValueMap, _roleDataMap, RoleDataMap);
    //RoleAnimationData getRoleAnimationDataWithName(const std::string &name);
    HeroData getHeroDataMapWithName(const std::string &name);
    void getRoleAnimationData(RoleAnimationData*data,ValueMap animData);
    Enemy getEnemyMapWithName(const std::string &name);
    
};
#endif /* DataManager_hpp */
