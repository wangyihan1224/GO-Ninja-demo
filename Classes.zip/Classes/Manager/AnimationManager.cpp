//
//  AnimationManager.cpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/21.
//
//

#include "AnimationManager.hpp"
static AnimationManager*animationManager=nullptr;

AnimationManager*AnimationManager::getInstance(){
    if (nullptr==animationManager) {
        animationManager=new AnimationManager;
        animationManager->init();
    }return  animationManager;

}
void AnimationManager::init(){
    
    auto animationMap=DataManager::getInstance()->getAnimationMap();
    
    
    
    
//    AnimationData data=DataManager::getInstance()->getAnimationDataWithName("Ninja_Run");
//    this->createAnimation(data);
//    AnimationCache::getInstance()->addAnimation(this->createAnimation(data), data.animationKey);
    for (auto ani:animationMap) {
        std::pair<std::string, Value>p=ani;
        std::string key=p.first;
        AnimationData data=DataManager::getInstance()->getAnimationDataWithName(key);
        Animation*animation=this->createAnimation(data);
        AnimationCache::getInstance()->addAnimation(animation, data.animationKey);
       // std::string value=p.second;
    }
    
}
Animation*AnimationManager:: createAnimation(AnimationData data){
    return this->createAnimation(data.fileName.c_str(), data.row, data.col, data.startIndex, data.stopIndex, data.delayPerUnit, data.loop);

}
Animation*AnimationManager:: createAnimation(const char* fileName,int row,int col,int startIndex,int stopIndex,float delayPerunit,int loop){
    auto animation=Animation::create();
    auto texture=Director::getInstance()->getTextureCache()->addImage(fileName);
    auto width=texture->getContentSize().width/col;
    auto height=texture->getContentSize().height/row;
    for (int i=startIndex; i<=stopIndex; i++) {
        auto frame=SpriteFrame::createWithTexture(texture, Rect(i%col*width, i/col*height, width, height));
        animation->addSpriteFrame(frame);
    }
    animation->setDelayPerUnit(delayPerunit);
    animation->setLoops(loop);
    return animation;
}
Animation*AnimationManager::getAnimationFromCache(const std::string &name){
    return  AnimationCache::getInstance()->getAnimation(name);

}