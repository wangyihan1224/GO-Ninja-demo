//
//  DataManager.cpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/21.
//
//

#include "DataManager.hpp"
static DataManager*dataManager=nullptr;

DataManager*DataManager::getInstance(){
    if (nullptr==dataManager) {
        dataManager=new DataManager;
       dataManager->init();
    }return  dataManager;
    
}
void DataManager::init(){
    _animationMap=FileUtils::getInstance()->getValueMapFromFile("Data/AnimationData.plist");
    _roleDataMap=FileUtils::getInstance()->getValueMapFromFile("Data/RoleData.plist");
}
AnimationData DataManager::getAnimationDataWithName(const std::string &name){

    ValueMap aniData=_animationMap.at(name).asValueMap();
    AnimationData data;
    data.animationKey=aniData.at("animationKey").asString();
    data.fileName=aniData.at("fileName").asString();
    data.row=aniData.at("row").asInt();
    data.col=aniData.at("col").asInt();
    data.startIndex=aniData.at("startIndex").asInt();
    data.stopIndex=aniData.at("stopIndex").asInt();
    data.delayPerUnit=aniData.at("delayPerUnit").asFloat();
    data.loop=aniData.at("loop").asInt();
    return data;
}
HeroData DataManager::getHeroDataMapWithName(const std::string &name){

    ValueMap heroData=_roleDataMap.at(name).asValueMap();
    HeroData data;
    data.speed=heroData.at("speed").asFloat();
    data.jumpTime=heroData.at("jumpTime").asInt();
    data.jumpHeight=heroData.at("jumpHeight").asFloat();
    data.coefficient=heroData.at("coefficient").asFloat();
    this->getRoleAnimationData(&(data.runAnim), heroData.at("runAnim").asValueMap());
    this->getRoleAnimationData(&(data.willDieAnim), heroData.at("willDieAnim").asValueMap());
    this->getRoleAnimationData(&(data.jumpDownAnim), heroData.at("jumpDownAnim").asValueMap());
     this->getRoleAnimationData(&(data.jumpAnim), heroData.at("jumpUpAnim").asValueMap());
     this->getRoleAnimationData(&(data.attackAnim), heroData.at("attackAnim").asValueMap());
     this->getRoleAnimationData(&(data.dustAnim), heroData.at("dust").asValueMap());
    
    return data;
    
    
 
    
}
void DataManager::getRoleAnimationData(RoleAnimationData*data,ValueMap animData){
    data->animName=animData.at("animName").asString();
    ValueVector point=animData.at("anchorPoint").asValueVector();
    data->anchorPoint=Vec2(point.at(0).asFloat(),point.at(1).asFloat());
    point=animData.at("collisionStartPos").asValueVector();
    data->collisionStartPos=Vec2(point.at(0).asFloat(),point.at(1).asFloat());
    ValueVector size=animData.at("collisionSize").asValueVector();
    data->collisionSize=Vec2(point.at(0).asFloat(),point.at(1).asFloat());

    
}
Enemy DataManager::getEnemyMapWithName(const std::string &name){

    
    ValueMap enemyData=_roleDataMap.at(name).asValueMap();
    Enemy data;
    data.harm=enemyData.at("harm").asInt();
    this->getRoleAnimationData(&(data.standAnim), enemyData.at("standAnim").asValueMap());
    if (-1!=data.harm) {
       this->getRoleAnimationData(&(data.willDieAnim), enemyData.at("willDieAnim").asValueMap());
        
    }
    
    auto iter=enemyData.find("willDieAnim");
    if (iter !=enemyData.end()) {
        this->getRoleAnimationData(&(data.willDieAnim), enemyData.at("willDieAnim").asValueMap());
    }
    return  data;
}