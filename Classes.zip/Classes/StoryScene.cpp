//
//  StoryScene.cpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/18.
//
//

#include "StoryScene.hpp"

std::string text[]={
    "坂田城堡，20xx年,这是一个忍者和魔法的时代。",
    "主公，坂田银时",
    "忍者，我们此刻的情况很严重",
    "我知道！",
    "那么你能理解，小田通过黑暗魔法已经占领了我整个武士军队",
    "他们杀死了所有的人，袭击城堡，城市已经沦陷",
    "主公，你受伤了？",
    "不用介意我，我叫你来只为一个目的",
    "你要消灭所有的黑暗武士，消灭小田",
    "你要帮我报仇，把他们都杀光！"
};

bool StoryScene::init(){

    if (!Scene::init())
        return false;
    _fristLayer=CSLoader::createNode("Csd/StoryScene/FirstLayer.csb");
    _secondLayer=CSLoader::createNode("Csd/StoryScene/SecondLayer.csb");
    _thirdLayer=CSLoader::createNode("Csd/StoryScene/ThirdLayer.csb");
    _fourthLayer=CSLoader::createNode("Csd/StoryScene/FourthLayer.csb");
    _fifthLayer=CSLoader::createNode("Csd/StoryScene/FiweLayer.csb");
    this->addChild(_fristLayer);
    this->addChild(_secondLayer);
    this->addChild(_thirdLayer);
    this->addChild(_fourthLayer);
    this->addChild(_fifthLayer);
   _fristLayer->setVisible(false);
    _secondLayer->setVisible(false);
    _thirdLayer->setVisible(false);
    _fourthLayer->setVisible(false);
    _fifthLayer->setVisible(false);
    //创建所有自动文本对象
    for (int i=0; i<sizeof(text)/sizeof(std::string); i++) {
        _lineFees.pushBack(LineFeed::createLineFeed(text[i], "fonts/微软雅黑.ttf", 24, 20, 0.05));
    }
    
        return true;
}
void StoryScene::onEnterTransitionDidFinish(){
//显示第一个层
    this->showFirstLayer();
    //this->showSecondLayer();
   //this->showThirdLayer();
    //this->showFourthLayer();
    //this->showFiveLayer();
}
void StoryScene::showFirstLayer(){
_fristLayer->setVisible(true);
    auto action=CSLoader::createTimeline("Csd/StoryScene/FirstLayer.csb");
    _fristLayer->runAction(action);
    action->gotoFrameAndPlay(0,false);
    
    auto lineFeed=_lineFees.at(0);
    lineFeed->setPosition(Vec2(200,100));
    this->addChild(lineFeed);
    lineFeed->onStartShow();
    lineFeed->setFinisCallBack([=](){this->removeChild(_fristLayer);
        this->removeChild(lineFeed);

        this->showSecondLayer();
        
    });
}
void StoryScene::showSecondLayer(){
    _secondLayer->setVisible(true);
    auto action=CSLoader::createTimeline("Csd/StoryScene/SecondLayer.csb");
    _secondLayer->runAction(action);
    action->gotoFrameAndPlay(0,false);
    //2
    //3
    auto lineFeed=_lineFees.at(1);
this->addChild(lineFeed);
    lineFeed->setPosition(Vec2(800,100));
    lineFeed->onStartShow();
    lineFeed->setFinisCallBack([=](){
    this->removeChild(lineFeed);
        auto lineFeed2=_lineFees.at(2);
        
        
        this->addChild(lineFeed2);
        lineFeed2->setPosition(Vec2(150,100));
        lineFeed2->onStartShow();
        lineFeed2->setFinisCallBack([=](){
            this->removeChild(lineFeed2);
            auto lineFeed3=_lineFees.at(3);
            this->addChild(lineFeed3);
            lineFeed3->setPosition(Vec2(800,100));
            
            lineFeed3->onStartShow();
            lineFeed3->setFinisCallBack([=](){
                this->removeChild(_secondLayer);
                
                this->removeChild(lineFeed3);
                this->showThirdLayer();
            });
        });

    });
                               
    
}
void StoryScene::showThirdLayer(){
    _thirdLayer->setVisible(true);
    auto action=CSLoader::createTimeline("Csd/StoryScene/ThirdLayer.csb");
    _thirdLayer->runAction(action);
    action->gotoFrameAndPlay(0);
    
    //4
    //5
    auto lineFeed=_lineFees.at(4);
    this->addChild(lineFeed);
    lineFeed->setPosition(Vec2(150,100));
    lineFeed->onStartShow();
    lineFeed->setFinisCallBack([=](){
        this->removeChild(lineFeed);
        auto lineFeed2=_lineFees.at(5);
        
        
        this->addChild(lineFeed2);
        lineFeed2->setPosition(Vec2(150,100));
        lineFeed2->onStartShow();
        lineFeed2->setFinisCallBack([=](){
            this->removeChild(lineFeed2);
            
                this->removeChild(_thirdLayer);
                
            
            this->showFourthLayer();
        });
        
    });

}
void StoryScene::showFourthLayer(){
    _fourthLayer->setVisible(true);
    auto action=CSLoader::createTimeline("Csd/StoryScene/FourthLayer.csb");
    _fourthLayer->runAction(action);
    action->gotoFrameAndPlay(0,false);
    //6
    //7
    //8
    //9
    auto lineFeed=_lineFees.at(6);
    this->addChild(lineFeed);
    lineFeed->setPosition(Vec2(800,100));
    lineFeed->onStartShow();
    lineFeed->setFinisCallBack([=](){
        this->removeChild(lineFeed);
        auto lineFeed2=_lineFees.at(7);
        
        
        this->addChild(lineFeed2);
        lineFeed2->setPosition(Vec2(150,100));
        lineFeed2->onStartShow();
        lineFeed2->setFinisCallBack([=](){
            this->removeChild(lineFeed2);
            auto lineFeed3=_lineFees.at(8);
            this->addChild(lineFeed3);
            lineFeed3->setPosition(Vec2(150,100));
            
            lineFeed3->onStartShow();
            lineFeed3->setFinisCallBack([=](){
               
                
                this->removeChild(lineFeed3);
                
                auto lineFeed4=_lineFees.at(9);
                this->addChild(lineFeed4);
                lineFeed4->setPosition(Vec2(150,100));
                lineFeed4->onStartShow();
                lineFeed4->setFinisCallBack([=](){
                    this->removeChild(lineFeed4);

                 this->removeChild(_fourthLayer);
                    this->showFiveLayer();
                });
            });
        });
        
    });

}
void StoryScene::showFiveLayer(){
    //定时器   两秒钟后执行回调方法，跳转到下一个场景
    _fifthLayer->setVisible(true);
    auto action=CSLoader::createTimeline("Csd/StoryScene/FiweLayer.csb");
    _fifthLayer->runAction(action);
    action->gotoFrameAndPlay(0);

    this->scheduleOnce([](float dt){
        Director::getInstance()->replaceScene(TransitionFade::create(1, LoadingScene::createScene()));
        log("跳转到下一个场景");}, 2, "scheduleOnce");
    

}