//
//  MenuScene.cpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/17.
//
//

#include "MenuScene.hpp"
#include "define.h"
bool MenuScene::init(){
    if (!Scene::init())
        return false;
    //界面
    auto menuLayer=CSLoader::createNode(menuscene_csb);
    this->addChild(menuLayer);
   // 动画
    
    auto action=CSLoader::createTimeline(menuscene_csb);
    menuLayer->runAction(action);
    //动画开始运行
    action->gotoFrameAndPlay(0, false);
    //Button_1
    
    auto startButton=dynamic_cast<Button*>(menuLayer->getChildByName("Button_1"));
//    startButton->addTouchEventListener([](Ref*ref,Widget::TouchEventType type){
//        log("跳转场景");
//    });
    startButton->addTouchEventListener(CC_CALLBACK_2(MenuScene::changeScene, this));
    
    
}
void MenuScene::changeScene(Ref*ref,Widget::TouchEventType type) {
    if (Widget::TouchEventType::ENDED==type) {
        
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, StoryScene::create()));
        log("跳转场景");
        
    }

}