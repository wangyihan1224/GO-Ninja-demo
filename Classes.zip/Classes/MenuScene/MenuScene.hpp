//
//  MenuScene.hpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/17.
//
//

#ifndef MenuScene_hpp
#define MenuScene_hpp

#include <stdio.h>
#include "cocos2d.h"
#include "ui/CocosGui.h"
#include "cocostudio/CocoStudio.h"
#include "StoryScene.hpp"
USING_NS_CC;
using namespace ui;
class MenuScene:public Scene{

public:
    CREATE_FUNC(MenuScene);
    bool init();
private:
    void changeScene(Ref*ref,Widget::TouchEventType type);
};

#endif /* MenuScene_hpp */
