//
//  LineFeed.cpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/18.
//
//

#include "LineFeed.hpp"
LineFeed*LineFeed:: createLineFeed(const std::string& text,const std::string& fontFile,float fontSize,int numInline,float interval){

    auto lineFeed=new LineFeed;
    if (lineFeed&&lineFeed->initLineFeed(text, fontFile, fontSize, numInline, interval)) {
        lineFeed->autorelease();
        return lineFeed;
    }CC_SAFE_DELETE(lineFeed);
    return nullptr;
}
bool LineFeed::initLineFeed(const std::string& text,const std::string& fontFile,float fontSize,int numInline,float interval){
    _content=text;
    _showContent="";
    _fontFile=fontFile;
    _fontSize=fontSize;
    _interval=interval;
    _leltterIndex=0;
   
    
    //Label的配置对象
    TTFConfig ttfConfig;
    ttfConfig.fontFilePath=_fontFile;
    ttfConfig.fontSize=_fontSize;
    ttfConfig.glyphs=GlyphCollection::DYNAMIC;
    _showLabel=Label::createWithTTF(ttfConfig, _showContent);
    this->addChild(_showLabel);
    //_fonSize是固定大笑，但是不同的分辨率为了做适配会进行缩放，那么屏幕中的字也应该跟着所发，所以这里用 字原来的大小乘以 适配时的缩放值
    _fontWidth=_fontSize*Director::getInstance()->getContentScaleFactor();
    _fontHeight=_showLabel->getLineHeight();
    _showLabel->setWidth(_fontWidth*numInline);
    _showLabel->setAnchorPoint(Vec2(0,1));
    
    
    return true;
}
void LineFeed::onStartShow(){
    this->schedule([this](float dt){if(_leltterIndex>_content.length()-1){this->unschedule("schedule");
        //全部显示完成
        log("全部显示完成,执行一些事");
        if (_finishCallBack) {
            _finishCallBack();
        }
            }
        _showContent+=_content[_leltterIndex];
        _showLabel->setString(_showContent);
        _leltterIndex++;
    }, _interval, "schedule");
   

}
void LineFeed::setFinisCallBack(std::function<void()>   finishCallBack){
    _finishCallBack=finishCallBack;

}