//
//  LineFeed.hpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/18.
//
//

#ifndef LineFeed_hpp
#define LineFeed_hpp
//#include "define.h"
#include <stdio.h>
#include "cocos2d.h"
USING_NS_CC;
class LineFeed:public Node{
public:
    //参数 文本内容 字体文件名 字体大小 每行多少个字 每两个字的播放间隔时间
    static LineFeed*createLineFeed(const std::string& text,const std::string& fontFile,float fontSize,int numInline,float interval);
    bool initLineFeed(const std::string& text,const std::string& fontFile,float fontSize,int numInline,float interval);
    void onStartShow();
    //设置回调方法
    void setFinisCallBack(std::function<void()> finishCallBack);
private:
   
    
    Label*_showLabel;
    //全部内容
    std::string _content;
    //已经显示的内容
    std::string _showContent;
    //字体文件名
    std::string _fontFile;
    
    //字体大小
    float _fontSize;
    //每行多少个字
    int _numInline;
    //每两个字的播放间隔时间
    float _interval;
    //显示字符的索引
    int _leltterIndex;
    //每个字的宽
    float _fontWidth;
    // 每个字的高
    float _fontHeight;
    //全部显示完成执行的回调方法
    std::function<void()>_finishCallBack;
    
};
#endif /* LineFeed_hpp */
