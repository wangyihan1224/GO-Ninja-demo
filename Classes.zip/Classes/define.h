//
//  define.h
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/17.
//
//

#ifndef define_h
#define define_h
/*  */
#define menuscene_csb "Csd/MenuScene/MenuScene.csb"
#define SCREEN Director::getInstance()->getWinSize()
#define SCREEN_CENTER Vec2(SCREEN.width*0.5,SCREEN.height*0.5)   
/*游戏场景图片名称*/
#define maxProgress  16
#define BG_EvilSky "map/BG_EvilSky.jpg"
#define BG_Sky "map/BG_Sky.jpg"
#define BG_z5_Light "map/BG_z5_Light.png"
#define BG_z5_Light1 "map/BG_z5_Light1.png"
#define BG_z6_Screen1flr "map/BG_z6_Screen1flr.png"
#define BG_z6_Screen2flr "map/BG_z6_Screen2flr.png"
#define CloudForestWallGround "map/CloudForestWallGround.png"
#define ForegroundOjbects "map/ForegroundOjbects.png"
#define Sprite_JumpDashSmoke "Animation/Sprite_JumpDashSmoke.png"
#define Sprite_Ninja "Animation/Sprite_Ninja.png"
#define Sprite_NinjaCloseSlash_v0 "Animation/Sprite_NinjaCloseSlash_v0.png"
#define Sprite_Soldier1 "Animation/Sprite_Soldier1.png"
#define Sprite_Soldier2 "Animation/Sprite_Soldier2.png"
#define Sprite_Soldier3 "Animation/Sprite_Soldier3.png"
#define Sprite_Speardeath_v0 "Animation/Sprite_Speardeath_v0.png"
#define Sprite_SpearSoldiers "Animation/Sprite_SpearSoldiers.png"

#define houseWidth  900
#endif /* define_h */
