//
//  SkyLayer.cpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/18.
//
//

#include "SkyLayer.hpp"
bool SkyLayer::init(){

    if (!Layer::init()) {
        return false;
    }
    auto  background1=Sprite::create(BG_Sky);
    background1->setAnchorPoint(Vec2(0,1));
    background1->setPositionY(SCREEN.height);
    auto background2=Sprite::create(BG_EvilSky);
    background2->setAnchorPoint(Vec2(0,1));
    background2->setPositionY(SCREEN.height-background1->getContentSize().height);
    this->addChild(background1);
    this->addChild(background2);
    float moveHeight=background1->getContentSize().height+background2->getContentSize().height-SCREEN.height+250;
    background1->runAction(MoveBy::create(100, Vec2(0,moveHeight)));
    background2->runAction(MoveBy::create(100, Vec2(0,moveHeight)));
    
    
    return true;
}