//
//  BackGroundLayer.cpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/19.
//
//

#include "BackGroundLayer.hpp"
bool BackGroundLayer::init(){
    if (!Layer::init()) {
        return false;
        
    }
    SpriteFrameCache::getInstance()->addSpriteFramesWithFile("map/CloudForestWallGround.plist");
    
    _initCloundY=500;
    _initForestY=260;
    _initWallY=0;
    _initGroundY=0;
//    _clound1=Sprite::createWithSpriteFrameName("Cloud.png");
//    this->addChild(_clound1);
//    _clound1->setAnchorPoint(Vec2::ZERO);
//    _clound1->setPosition(0,_initCloundY);
    //
    this->createSprite(_clound1, "Cloud.png", Vec2(0, _initCloundY));
    this->createSprite(_clound2, "Cloud.png", Vec2(_clound1->getContentSize().width, _initCloundY));
    this->createSprite(_forest1, "Forest.png", Vec2(0, _initForestY));
    this->createSprite(_forest2, "Forest.png", Vec2(_forest1->getContentSize().width, _initForestY));
    this->createSprite(_wall1, "Wall.png", Vec2(0, _initWallY));
    this->createSprite(_wall2, "Wall.png", Vec2(_wall1->getContentSize().width, _initWallY));
    this->createSprite(_ground1, "Ground.png", Vec2(0, _initGroundY));
    _ground1->setGlobalZOrder(1);
    this->createSprite(_ground2, "Ground.png", Vec2(_ground1->getContentSize().width, _initGroundY));
    _ground2->setGlobalZOrder(1);
    return true
    ;

}
//
void BackGroundLayer::createSprite(Sprite* &sprite,const char*fameName,Vec2 position){
    sprite=Sprite::createWithSpriteFrameName(fameName);
    this->addChild(sprite);
    sprite->setAnchorPoint(Vec2::ZERO);
    sprite->setPosition(position);

}
// 判断如果 精灵1出了 放精灵2后面
void BackGroundLayer::spriteMove_X(Sprite*sprite1,Sprite*sprite2,float speed_x){
    sprite1->setPositionX(sprite1->getPositionX()-speed_x);
    sprite2->setPositionX(sprite2->getPositionX()-speed_x);
    if (sprite1->getPositionX()<=-sprite1->getContentSize().width) {
        sprite1->setPositionX(sprite2->getPositionX()+sprite2->getContentSize().width);
    }
    if (sprite2->getPositionX()<=-sprite2->getContentSize().width) {
        sprite2->setPositionX(sprite1->getPositionX()+sprite1->getContentSize().width);
    }

}
void BackGroundLayer::move(float speed){
//移动云
    this->spriteMove_X(_clound1, _clound2, speed/5);
    //
    this->spriteMove_X(_forest1, _forest2, speed/5*2);
    this->spriteMove_X(_wall1, _wall2, speed/5*4);
    this->spriteMove_X(_ground1, _ground2, speed);
}
void BackGroundLayer::moveY(float moveY){
    _clound1->setPositionY(_initCloundY-moveY/25);
    _clound2->setPositionY(_initCloundY-moveY/25);
    _forest1->setPositionY(_initForestY-moveY/14);
    _forest2->setPositionY(_initForestY-moveY/14);
    _ground1->setPositionY(_initGroundY-moveY/2);
    _ground2->setPositionY(_initGroundY-moveY/2);
    _wall1->setPositionY(_initWallY-moveY/10);
    _wall2->setPositionY(_initWallY-moveY/10);
}