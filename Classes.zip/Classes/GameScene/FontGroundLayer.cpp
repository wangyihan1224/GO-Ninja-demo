//
//  FontGroundLayer.cpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/19.
//
//

#include "FontGroundLayer.hpp"
bool FontGroundLayer::init(){

    if (!Layer::init()) {
        return false;
    }
    SpriteFrameCache::getInstance()->addSpriteFramesWithFile("map/ForegroundOjbects.plist");
    this->schedule([=](float dt){
        char buffer[100];
        sprintf(buffer,"Foreground%d.png",rand()%4+1);
        _fond=Sprite::createWithSpriteFrameName(buffer);
        _fond->setAnchorPoint(Vec2::ZERO);
        _fond->setPositionX(SCREEN.width);
        _fond->setGlobalZOrder(3);
        this->addChild(_fond);
    }, 10,"schedule");
    
    return true;
}

void FontGroundLayer::move(float speed){
    if (nullptr!=_fond) {
        _fond->setPositionX(_fond->getPositionX()-speed*3);
        if (_fond->getPositionX()<=-_fond->getContentSize().width) {
            this->removeChild(_fond);
            _fond=nullptr;
        }
    }
    
}
