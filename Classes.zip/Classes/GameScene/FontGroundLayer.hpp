//
//  FontGroundLayer.hpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/19.
//
//

#ifndef FontGroundLayer_hpp
#define FontGroundLayer_hpp
#include "define.h"
#include <stdio.h>
#include "cocos2d.h"
USING_NS_CC;
class FontGroundLayer:public Layer{
public:
    CREATE_FUNC(FontGroundLayer);
    bool init();
    void move(float speed);
   
private:
    Sprite*_fond;
   
};
#endif /* FontGroundLayer_hpp */
