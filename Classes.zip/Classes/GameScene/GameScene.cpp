//
//  GameScene.cpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/18.
//
//

#include "GameScene.hpp"
#define speed 10
bool GameScene::init(){

    if (!Scene::init()) {
        GameScene::init();
    }
//    SimpleAudioEngine::getInstance()->playBackgroundMusic("bg4.mp3",true);
    //AnimationManager::getInstance();
    //天空
    this->initSkyLayer();
    //背景
    this->initBackGroundLayer();
    //游戏层
    this->initGameLayer();
    //前景
    this->initFontGroundLayer();
    this->schedule(CC_CALLBACK_1(GameScene::move,this), "schedule");
    return true;
}

void GameScene::initBackGroundLayer(){
    bgl=BackGroundLayer::create();
    this->addChild(bgl);

}
void GameScene::initFontGroundLayer(){
    fgl=FontGroundLayer::create();
    this->addChild(fgl);
}
void GameScene::initSkyLayer(){

    auto skyLayer=SkyLayer::create();
    this->addChild(skyLayer);
}
void GameScene::move(float dt){
    //背景移动
        bgl->move(speed);
    //游戏层逻辑
    _gl->move(speed);
    
    _gl->GameLogic();
    //前景移动
    fgl->move(speed);
    
    this->moveY();
}
void GameScene::moveY(){
    float _moveY=_gl->getMoveHeight();
    _gl->setPositionY(-_moveY/2);
    bgl->moveY(_moveY);
     fgl->setPositionY(-_moveY/2);
}
void GameScene::initGameLayer(){
    _gl=GameLayer::create();
    this->addChild(_gl);


    
}
void GameScene::stop(){
    this->unschedule("schedule");
}