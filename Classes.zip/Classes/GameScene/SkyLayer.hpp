//
//  SkyLayer.hpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/18.
//
//

#ifndef SkyLayer_hpp
#define SkyLayer_hpp
#include "define.h"
#include <stdio.h>
#include "cocos2d.h"
USING_NS_CC;
class SkyLayer :public Layer{
public:
    CREATE_FUNC(SkyLayer);
    bool init();

};
#endif /* SkyLayer_hpp */
