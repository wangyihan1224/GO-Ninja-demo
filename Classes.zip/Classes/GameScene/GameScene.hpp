//
//  GameScene.hpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/18.
//
//

#ifndef GameScene_hpp
#define GameScene_hpp
#include <stdio.h>
#include "SkyLayer.hpp"
#include "BackGroundLayer.hpp"
#include "FontGroundLayer.hpp"
#include "AnimationManager.hpp"
#include "cocos2d.h"

#include "GameLayer.hpp"
#include "SimpleAudioEngine.h"
USING_NS_CC;
using namespace CocosDenshion;
class GameScene:public Scene{
public:
    CREATE_FUNC(GameScene);
    
    bool init();
    void stop();
private:
    BackGroundLayer*bgl;
    FontGroundLayer*fgl;
    GameLayer*_gl;
    void move(float dt);
    void moveY();
    
    void initSkyLayer();
    void initBackGroundLayer();
    void initFontGroundLayer();
    void initGameLayer();
    
}
;
#endif /* GameScene_hpp */
