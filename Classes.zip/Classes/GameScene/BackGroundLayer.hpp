//
//  BackGroundLayer.hpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/19.
//
//

#ifndef BackGroundLayer_hpp
#define BackGroundLayer_hpp
#include "cocos2d.h"
#include <stdio.h>
#include "define.h"
USING_NS_CC;
class BackGroundLayer:public Layer{
public:
    
    CREATE_FUNC(BackGroundLayer);
    bool init();
    void move(float speed);
     void moveY(float moveY);
private:
    Sprite*_clound1;
    Sprite*_clound2;
    Sprite*_forest1;
    Sprite*_forest2;
    Sprite*_wall1;
    Sprite*_wall2;
    Sprite*_ground1;
    Sprite*_ground2;
    float _initCloundY;
    float _initForestY;
    float _initWallY;
    float _initGroundY;
    //创建精灵的 方法
    
    void createSprite(Sprite* &sprite,const char*fameName,Vec2 position);
    //
    void spriteMove_X(Sprite*sprite1,Sprite*sprite2,float speed_x);
};
#endif /* BackGroundLayer_hpp */
