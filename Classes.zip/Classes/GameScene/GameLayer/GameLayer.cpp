//
//  GameLayer.cpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/21.
//
//

#include "GameLayer.hpp"
#include "GameScene.hpp"
bool GameLayer::init(){
    if (!Layer::init()) {
        return false;
    }
    SimpleAudioEngine::getInstance()->stopAllEffects();
    SimpleAudioEngine::getInstance()->playBackgroundMusic("gamelayer.mp3",true);
//    auto house=HouseNode::createHouse(House_Type::FRIST_FLOOR);
//    this->addChild(house);
//    house->setPositionY(100);
  //this->addHouseToGameLayer();
    _addHousePos=this->getAddHousePos();
    _houseMoveDestance=0;
     _addEnemyPos=this->getAddEnemyPos();
    _enemyMoveDestance=0;
//    auto sprite=Sprite::create();
//    this->addChild(sprite);
//    sprite->setPosition(Vec2(400, 100));
//    sprite->setGlobalZOrder(2);
//    sprite->runAction(Animate::create(AnimationManager::getInstance()->getAnimationFromCache("Ninja_Run")));
    _ninja=NinjaNode::create();
    this->addChild(_ninja);
 //_ninja->setPosition(Vec2(200, 100));
    return true;


}
void GameLayer::GameLogic(){
    _ninja->logic();
}
void GameLayer::move(float speed){
    _houseMoveDestance+=speed;
    if (_houseMoveDestance>_addHousePos) {
        this->addHouseToGameLayer();
        _addHousePos=this->getAddHousePos();
        _houseMoveDestance=0;
    }
    this->houseMove(speed);
    _enemyMoveDestance+=speed;
    if (_enemyMoveDestance>_addEnemyPos) {
        this->addEnemyToGameLayer();
        _addEnemyPos=this->getAddEnemyPos();
        _enemyMoveDestance=0;
    }
    this->enemyMove(speed);
    this->ninjaAndHouseCollision();
}
float GameLayer::getMoveHeight(){
  return  _ninja->getJumpHeight();
}
void  GameLayer::addHouseToGameLayer(){

    House_Type type=(House_Type)(rand()% TYPE_COUNT);
    auto house=HouseNode::createHouse(type);
    house->setPosition(Vec2(SCREEN.width,100));
    this->addChild(house,-1);
    _houses.pushBack(house);
    int addEnemyNum=rand()%4;
    float randW=house->getcollisionWidth()-125;
    for (int i=0; i<addEnemyNum; i++) {
        Enemy_Type type=(Enemy_Type)(rand()%6);
        
        
        auto enemy=EnemyNode::createEnemyWithType(type);
        
        
        this->addChild(enemy);
        float x=house->getPositionX()+randW-randW/5-(randW/4*i);
        int random=rand()%(house->getcollisionPos_Y().size());
        _enemys.pushBack(enemy);
        enemy->setPosition(Vec2(x,house->getcollisionPos_Y().at(random).asFloat()+100));
    }
    
    
}
void  GameLayer::houseMove(float speed){
    for (auto house:_houses) {
        house->setPositionX(house->getPositionX()-speed);
        if (house->getPositionX()<=-house->getContentSize().width) {
            _removeHouses.pushBack(house);
        }
    }
    for (auto removeHouse:_removeHouses) {
        this->removeChild(removeHouse);
        _houses.eraseObject(removeHouse);
        
    }
    _removeHouses.clear();
}

float GameLayer::getAddHousePos(){
    return rand()%((int)SCREEN.width*2)+houseWidth;
}
void GameLayer::addEnemyToGameLayer(){
    Enemy_Type type=(Enemy_Type)(rand()%(int)Enemy_Type::ENEMY_COUNT);
    
   
    auto enemy=EnemyNode::createEnemyWithType(type);
    
   enemy->setPosition(Vec2(SCREEN.width+enemy->getCollisionArea().size.width*0.5, 100));
    this->addChild(enemy);
    _enemys.pushBack(enemy);
}
void  GameLayer::enemyMove(float speed){
    for (auto enemy:_enemys) {
        enemy->setPositionX(enemy->getPositionX()-speed);
        
            if(_ninja->getCollisionArea().intersectsRect(enemy->getCollisionArea())) {
                if (enemy->getIsDeadly()) {
                    _ninja->die();
                    //((GameScene*)Director::getInstance()->getRunningScene())->stop();
                    //(GameScene*)this->getParent();
                    
                }else{
            if (!enemy->getIsDie()) {
              
                if (_ninja->getIsAttack()) {
                    SimpleAudioEngine::getInstance()->playEffect("attack.wav");
                    enemy->die();
                    enemy->setIsDie(true);}
                    else{}
            }}}
    
        if (enemy->getPositionX()<=-(enemy->getContentSize().width)) {
            _removeEnemys.pushBack(enemy);
        }
    }
    for (auto removeEnemy:_removeEnemys) {
        this->removeChild(removeEnemy);
        _enemys.eraseObject(removeEnemy);
        
    }
    _removeEnemys.clear();
}
float GameLayer::getAddEnemyPos(){
return rand()%400+100;

}
void GameLayer::ninjaAndHouseCollision(){
    for (auto house:_houses) {
        if (_ninja->getCollisionArea().getMidX()>house->getcollisionStartPos_X()&&_ninja->getCollisionArea().getMidX()<=house->getcollisionWidth()+house->getcollisionStartPos_X()) {
            _ninja->restRoof_Ys(house->getcollisionPos_Y());
            return;
        }
    }_ninja->cleanRoof_Ys();
}