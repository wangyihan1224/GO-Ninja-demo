//
//  GameLayer.hpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/21.
//
//

#ifndef GameLayer_hpp
#define GameLayer_hpp
#include "AnimationManager.hpp"
#include <stdio.h>
#include "cocos2d.h"
#include "HouseNode.hpp"
#include "define.h"
#include "EnemyNode.hpp"
#include "NinjaNode.hpp"
#include "SimpleAudioEngine.h"
USING_NS_CC;
using namespace CocosDenshion;

class GameLayer:public Layer{
public:
    CREATE_FUNC(GameLayer);
    bool init();
    //const std::string fileName;
    void move(float speed);
    void GameLogic();
    float getMoveHeight();
private:
    NinjaNode * _ninja;
    Vector<HouseNode*>_houses;
    
    Vector<HouseNode*> _removeHouses;
    
    float _addHousePos;
    float _houseMoveDestance;
    
    
    void  addHouseToGameLayer();
    void  houseMove(float speed);
    
    float getAddHousePos();
    Vector<EnemyNode*>_enemys;
    Vector<EnemyNode*>_removeEnemys;
    float _addEnemyPos;
    float _enemyMoveDestance;
    void addEnemyToGameLayer();
    void  enemyMove(float speed);
    float getAddEnemyPos();
    void ninjaAndHouseCollision();
}
;
#endif /* GameLayer_hpp */
