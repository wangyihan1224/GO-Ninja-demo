//
//  EnemyNode.cpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/22.
//
//

#include "EnemyNode.hpp"
EnemyNode*EnemyNode::createEnemyWithType(Enemy_Type type){
    auto enemyNode=new EnemyNode;
    if (enemyNode&&enemyNode->initEnemyWithType(type)) {
        enemyNode->autorelease();
        return enemyNode;
    }CC_SAFE_DELETE(enemyNode);
    return NULL;
}
bool EnemyNode::initEnemyWithType(Enemy_Type type){
    if (!RoleNode::init()) {
        return false;
    }
    
    char enemyName[100];
    sprintf(enemyName,"Enemy%d", static_cast<int>(type)+1);
    _data=DataManager::getInstance()->getEnemyMapWithName(enemyName);
    _isDeadly=false;
    _isDie=false;
    if (-1==_data.harm) {
        _isDeadly=true;
        _showSprite->setColor(Color3B(255, 0, 0));
        
    }
    this->standAnim();
    return true;
}
int EnemyNode::getHarm(){
    return _data.harm;

}

void EnemyNode::die(){
    this->willDieAnim();
}

void EnemyNode::standAnim(){
    this->runAnimation(_data.standAnim);
}
void EnemyNode::willDieAnim(){
    this->runAnimation(_data.willDieAnim);
    

}