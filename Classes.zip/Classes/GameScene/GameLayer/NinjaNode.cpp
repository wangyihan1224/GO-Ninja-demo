//
//  NinjaNode.cpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/23.
//
//

#include "NinjaNode.hpp"

bool NinjaNode::init(){
    if (!RoleNode::init()) {
        return false;
    }
    init_Y=100;
   isDownGround=true;
    _currentTime=0;
    
    this->setPosition(Vec2(200,init_Y));
    _state=Move;
    _data=DataManager::getInstance()->getHeroDataMapWithName("Hero");
    this->runRunAnimation();
    
    
    auto listener=EventListenerTouchAllAtOnce::create();
    listener->onTouchesBegan=CC_CALLBACK_2(NinjaNode::onTouchesBegan, this);
    Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(listener, this);
        return true;
    
    
}
void NinjaNode::attack(){
    _isAttack=true;
    this->runAttackAnimation();
}
void NinjaNode::die(){
    SimpleAudioEngine::getInstance()->playEffect("die.wav");
    this->runWillDieAnimation();
}
float NinjaNode::getJumpHeight(){
    return this->getPositionY()-init_Y;

}
void NinjaNode::onTouchesBegan(const std::vector<Touch*>& touches,Event *event){
    for (auto iter=touches.begin(); iter!=touches.end(); iter++) {
        auto pTouch= (Touch*)(*iter);
        if (pTouch->getLocation().x<SCREEN.width*0.5) {
            log("跳跃");
            this->startJump();
        }else{
            this->attack();
            log("攻击");
        }
    }

}
void NinjaNode::runJumpAnimation(){
    this->runAnimation(_data.jumpAnim);
}
void NinjaNode::runRunAnimation(){
    this->runAnimation(_data.runAnim);
}
void NinjaNode::runDownAnimation(){
    this->runAnimation(_data.jumpDownAnim);
}
void NinjaNode::runWillDieAnimation(){
this->runAnimation(_data.willDieAnim);
}
void NinjaNode::runDustAnimation(){
    auto dust=Sprite::create();
    this->getParent()->addChild(dust);
    dust->setAnchorPoint(_data.dustAnim.anchorPoint);
    dust->setPosition(this->getPosition());
    //this->addChild(dust);
    dust->runAction(Sequence::create(Animate::create(AnimationManager::getInstance()->getAnimationFromCache("Dust")),CallFunc::create([=](){
        dust->removeFromParent();
    }), NULL));
//this->runAnimation(_data.dustAnim);
}
void NinjaNode::runAttackAnimation(){
    this->runAnimation(_data.attackAnim,[=](){
        _isAttack=false;
        if (_state==Move) {
            
            this->runRunAnimation();
        }else if (_state==Jump_Up||_state==Jump_Down) {
           
            this->runDownAnimation();
        }
       
    });
}
void NinjaNode::downGround(){
    _state=Move;
    _currentTime=0;
    this->runDustAnimation();
    this->runRunAnimation();
}
bool NinjaNode::isWillDownGround(){
    if (this->getPositionY()-_currentJumpHeight<=init_Y) {
        this->setPositionY(init_Y);
        return true;
    }return false;
}
void NinjaNode::logic(){
    switch (_state) {
        case Move:
            this->moveLogic();
            break;
        case Jump_Down:
            this->jumpDownLogic();
            break;
        case Jump_Up:
            this->jumpUpLogic();
            break;
        
    }
}
void NinjaNode::moveLogic(){
    if (this->getPositionY()>init_Y&&_roof_Ys.empty()) {
        _state=Jump_Down;
        isDownGround=false;
        _currentJumpHeight=10;
        this->runDownAnimation();
    }
}
void NinjaNode::jumpUpLogic(){
    if (_currentJumpHeight<=0) {
        _currentJumpHeight=0;
        _state=Jump_Down;
    }
    this->setPositionY(this->getPositionY()+_currentJumpHeight);
    _currentJumpHeight-=_data.coefficient;
}
void NinjaNode::jumpDownLogic(){
    if (isDownGround) {
        this->downGround();
    }
    if (this->isWillDownGround()) {
        isDownGround=true;
        return;
    }
    for (auto lineY:_roof_Ys) {
        
        if (this->isWillDownHouse(lineY.asFloat())) {
            isDownGround=true;
        }
    }
    this->setPositionY(this->getPositionY()-_currentJumpHeight);
    _currentJumpHeight+=_data.coefficient;
}
void NinjaNode::startJump(){
//float _currentJumpHeight;
    if (_currentTime<_data.jumpTime) {
        if (Jump_Up!=_state) {
            _state=Jump_Up;
            isDownGround=false;
            
        }
        this->runJumpAnimation();
        this->runDustAnimation();
        _currentJumpHeight=_data.jumpHeight;
        _currentTime++;
    }
}
void NinjaNode::restRoof_Ys(ValueVector roof_Ys){
    _roof_Ys=roof_Ys;
}
void NinjaNode::cleanRoof_Ys(){
    _roof_Ys.clear();
}
bool NinjaNode::isWillDownHouse(float line){
    if (this->getPositionY()>line+init_Y&&this->getPositionY()-_currentJumpHeight<=line+init_Y) {
        this->setPositionY(line+init_Y);
        return true;
    }return false;
}