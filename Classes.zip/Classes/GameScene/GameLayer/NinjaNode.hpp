//
//  NinjaNode.hpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/23.
//
//

#ifndef NinjaNode_hpp
#define NinjaNode_hpp
#include "cocos2d.h"
#include "HeroData.h"
#include "RoleNode.hpp"
#include <stdio.h>
#include "DataManager.hpp"
#include "define.h"
#include "AnimationManager.hpp"
#include "SimpleAudioEngine.h"
USING_NS_CC;
using namespace CocosDenshion;
typedef enum{
Move,
    Jump_Up,
    Jump_Down
    
    
}Ninja_State;
class NinjaNode:public RoleNode{
public:
    CREATE_FUNC(NinjaNode);
    bool init();
    //CC_SYNTHESIZE(Ninja_State, _state, Ninja_state);
    CC_SYNTHESIZE(bool, _isAttack, IsAttack);
    void die();
    float getJumpHeight();
    void logic();
    void restRoof_Ys(ValueVector _roof_Ys);
    void cleanRoof_Ys();
private:
    float init_Y;
    Ninja_State _state;
    bool isDownGround;
    int _currentTime;
    float _currentJumpHeight;
    
    HeroData _data;
    void onTouchesBegan(const std::vector<Touch*>& touches,Event *event);
    void moveLogic();
    void jumpUpLogic();
    void jumpDownLogic();
    void startJump();
    void attack();
    void runAttackAnimation();
    void runJumpAnimation();
    void runRunAnimation();
    void runDownAnimation();
    void runWillDieAnimation();
    void runDustAnimation();
    void downGround();
    bool isWillDownGround();
    ValueVector _roof_Ys;
    bool isWillDownHouse(float line);
};
#endif /* NinjaNode_hpp */
