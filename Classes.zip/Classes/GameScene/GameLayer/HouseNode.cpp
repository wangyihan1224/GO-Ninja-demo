//
//  HouseNode.cpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/21.
//
//

#include "HouseNode.hpp"
HouseNode*HouseNode::createHouse(House_Type type){

    auto  house=new  HouseNode;
    if (house&&house->initHouse(type)) {
        house->autorelease();
        return house;
    }CC_SAFE_DELETE(house);
    return nullptr;
}
bool HouseNode::initHouse(House_Type type){
//    if (!Node::init()) {
//        return false;
//    }
    _type=type;
    bool isTowFloor=false;
    _collisionStartPos_X=80;
    _collisionWidth=730;
    auto house=Sprite::create("Game/BG_House.png");
    house->setAnchorPoint(Vec2::ZERO);
    this->addChild(house,0,100);
    
    switch ((int)_type) {
        case House_Type::FRIST_FLOOR:
        {house->setPositionY(-403);
            auto windows=Sprite::create(BG_z6_Screen1flr);
            windows->setAnchorPoint(Vec2::ZERO);
            this->addChild(windows);}

            break;
        case House_Type::SCEOND_FLOOR:
        {auto house2=Sprite::create("Game/BG_House.png");
            house2->setAnchorPoint(Vec2::ZERO);
            this->addChild(house2);
            
            house2->setPositionY(-403);
            auto windows=Sprite::create(BG_z6_Screen1flr);
            windows->setAnchorPoint(Vec2::ZERO);
            this->addChild(windows);
            auto windows2=Sprite::create(BG_z6_Screen2flr);
            windows2->setAnchorPoint(Vec2::ZERO);
            windows2->setPositionY(451);
            this->addChild(windows2);

            isTowFloor=true;}
            break;
        case House_Type::FRIST_FLOOR_LIGHT:
        {house->setPositionY(-403);
            auto light=Sprite::create(BG_z5_Light);
            
            light->setAnchorPoint(Vec2::ZERO);
            light->setPosition(Vec2(122, 57));
            this->addChild(light);
            auto windows=Sprite::create(BG_z6_Screen1flr);
            windows->setAnchorPoint(Vec2::ZERO);
            this->addChild(windows);}
            
            break;
        case House_Type::SCEOND_FLOOR_B_LIGHT:
        {auto house2=Sprite::create("Game/BG_House.png");
            house2->setAnchorPoint(Vec2::ZERO);
            this->addChild(house2);
            
            house2->setPositionY(-403);
            auto windows2=Sprite::create(BG_z6_Screen2flr);
            windows2->setAnchorPoint(Vec2::ZERO);
            windows2->setPositionY(451);
            this->addChild(windows2);
            auto light=Sprite::create(BG_z5_Light);
            
            light->setAnchorPoint(Vec2::ZERO);
            light->setPosition(Vec2(122, 57));
            this->addChild(light);
            auto windows=Sprite::create(BG_z6_Screen1flr);
            windows->setAnchorPoint(Vec2::ZERO);
            this->addChild(windows);
        isTowFloor=true;}
            
            break;
            case House_Type::SCEOND_FLOOR_T_LIGHT :
        {auto house2=Sprite::create("Game/BG_House.png");
            house2->setAnchorPoint(Vec2::ZERO);
            this->addChild(house2);
            
            house2->setPositionY(-403);
            auto light=Sprite::create(BG_z5_Light);
            
            light->setAnchorPoint(Vec2::ZERO);
            light->setPosition(Vec2(122, 497));
            this->addChild(light);
            auto windows2=Sprite::create(BG_z6_Screen2flr);
            windows2->setAnchorPoint(Vec2::ZERO);
            windows2->setPositionY(451);
            this->addChild(windows2);
            auto windows=Sprite::create(BG_z6_Screen1flr);
            windows->setAnchorPoint(Vec2::ZERO);
            this->addChild(windows);

            isTowFloor=true;
        }
            break;
            case House_Type::SCEOND_FLOOR_LIGHT:
            
        {auto house2=Sprite::create("Game/BG_House.png");
            house2->setAnchorPoint(Vec2::ZERO);
            this->addChild(house2);
            
            house2->setPositionY(-403);
            auto light=Sprite::create(BG_z5_Light);
            
            light->setAnchorPoint(Vec2::ZERO);
            light->setPosition(Vec2(122, 497));
            this->addChild(light);
            auto windows2=Sprite::create(BG_z6_Screen2flr);
            windows2->setAnchorPoint(Vec2::ZERO);
            windows2->setPositionY(451);
            this->addChild(windows2);
             auto light2=Sprite::create(BG_z5_Light);
            light2->setAnchorPoint(Vec2::ZERO);
            light2->setPosition(Vec2(122, 57));
            this->addChild(light2);
            auto windows=Sprite::create(BG_z6_Screen1flr);
            windows->setAnchorPoint(Vec2::ZERO);
            this->addChild(windows);
            
            isTowFloor=true;
        }

            break;
        
    }
    if (!isTowFloor) {
        _collisionPos_Y.push_back(Value(335));
    }else{
        _collisionPos_Y.push_back(Value(720));
        _collisionPos_Y.push_back(Value(335));
    
    }
    return true;

}

float HouseNode::getcollisionStartPos_X() const{

    return _collisionStartPos_X+this->getPositionX();
}
const Size& HouseNode::getContentSize() const{

    return this->getChildByTag(100)->getContentSize();
}