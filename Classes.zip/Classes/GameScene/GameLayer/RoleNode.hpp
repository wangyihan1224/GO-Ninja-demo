//
//  RoleNode.hpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/22.
//
//

#ifndef RoleNode_hpp
#define RoleNode_hpp
#include "cocos2d.h"
#include <stdio.h>
#include "RoleAnimationData.h"
#include "AnimationManager.hpp"
USING_NS_CC;
typedef std::function<void()> anim_callBack;
class RoleNode :public Node{
public:
    bool init();
    void runAnimation(RoleAnimationData data,anim_callBack onCallBack=NULL);
    Rect getCollisionArea();
    const Size& getContentSize() const override;
protected:
    Sprite*_showSprite;
private:
    
    Size _collisionSize;
    Vec2 _collisionStartPos;
};
#endif /* RoleNode_hpp */
