//
//  HouseNode.hpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/21.
//
//

#ifndef HouseNode_hpp
#define HouseNode_hpp

#include <stdio.h>
#include "cocos2d.h"
#include "define.h"
USING_NS_CC;
enum  House_Type{
    FRIST_FLOOR,
    SCEOND_FLOOR,
    FRIST_FLOOR_LIGHT,
    SCEOND_FLOOR_T_LIGHT,
    SCEOND_FLOOR_B_LIGHT,
    SCEOND_FLOOR_LIGHT,
    TYPE_COUNT

};
class HouseNode:public Node{
public:
    static HouseNode*createHouse(House_Type type);
    bool initHouse(House_Type type);
    CC_SYNTHESIZE(House_Type, _type, type);
    CC_SYNTHESIZE(ValueVector, _collisionPos_Y, collisionPos_Y);
    CC_PROPERTY_READONLY(float, _collisionStartPos_X, collisionStartPos_X);
     //CC_SYNTHESIZE(float, _collisionStartPos_X, collisionStartPos_X);
    CC_SYNTHESIZE_READONLY(float, _collisionWidth, collisionWidth);
    // CC_SYNTHESIZE(float, _collisionWidth, collisionWidth);
    virtual const Size& getContentSize() const;
};
#endif /* HouseNode_hpp */
