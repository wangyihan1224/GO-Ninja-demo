//
//  RoleNode.cpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/22.
//
//

#include "RoleNode.hpp"
bool RoleNode::init(){
    _showSprite=Sprite::create();
    this->addChild(_showSprite);
    return  true;

}
void RoleNode::runAnimation(RoleAnimationData data,anim_callBack onCallBack){
    auto animation=AnimationManager::getInstance()->getAnimationFromCache(data.animName);
    CCASSERT(animation!=nullptr, "animation must be non-nil");
    _collisionSize=data.collisionSize;
    _collisionStartPos=data.collisionStartPos;
    _showSprite->setAnchorPoint(data.anchorPoint);
    _showSprite->stopAllActions();
    auto*callFunc=CallFunc::create([onCallBack](){
        if (onCallBack!=NULL) {
            onCallBack();
        }
    });
    auto *sequence=Sequence::create(Animate::create(animation),callFunc,NULL);
    _showSprite->runAction(sequence);
    
}
Rect RoleNode::getCollisionArea(){
    return Rect(this->getPositionX(), this->getPositionY(), _collisionSize.width+_collisionStartPos.x, _collisionSize.height+_collisionStartPos.y);

}
const Size& RoleNode::getContentSize() const {
    return _showSprite->getContentSize();
    
}