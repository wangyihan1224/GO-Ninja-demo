//
//  EnemyNode.hpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/22.
//
//

#ifndef EnemyNode_hpp
#define EnemyNode_hpp
#include "DataManager.hpp"
#include <stdio.h>
#include "cocos2d.h"
#include "RoleNode.hpp"
#include "Enemy.h"
USING_NS_CC;
enum class Enemy_Type{
    ENEMY1,
    ENEMY2,
    ENEMY3,
    ENEMY4,
    ENEMY5,
    ENEMY6,
    ENEMY_COUNT
    
};
class EnemyNode:public RoleNode{
public:
    static EnemyNode*createEnemyWithType(Enemy_Type type);
    int getHarm();
    CC_SYNTHESIZE_READONLY(bool, _isDeadly, IsDeadly);
    CC_SYNTHESIZE(bool, _isDie, IsDie);
    void die();
    bool initEnemyWithType(Enemy_Type type);
private:
    Enemy _data;
    
    void standAnim();
   void willDieAnim();
};
#endif /* EnemyNode_hpp */
