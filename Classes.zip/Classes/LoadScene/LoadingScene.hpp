//
//  LoadingScene.hpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/18.
//
//

#ifndef LoadingScene_hpp
#define LoadingScene_hpp

#include <stdio.h>
#include "cocos2d.h"
#include "GameScene.hpp"
#include "define.h"
USING_NS_CC;

class LoadingScene:public Layer{
public:
    static Scene* createScene();
    CREATE_FUNC(LoadingScene);
    virtual void onEnterTransitionDidFinish();
private:
    //进度对象
    ProgressTimer*_progressTimer;
    bool init();
    //最大 有多少个资源要加载
    float _maxProgress;
    //当前加载的进度
    float _progress;
    //
    Label*_showPercent;
    //加载资源的方法
    void loadResoureces();
    //加载 每个资源的 回调方法
    void loadingCallBack(Texture2D*texture);
};
#endif /* LoadingScene_hpp */
