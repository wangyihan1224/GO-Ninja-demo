//
//  LoadingScene.cpp
//  Go_Ninja
//
//  Created by 王乙涵 on 16/2/18.
//
//

#include "LoadingScene.hpp"
#include "define.h"
Scene* LoadingScene::createScene(){
    auto scene=Scene::create();
    auto loadingLayer=LoadingScene::create();
    scene->addChild(loadingLayer);
    return scene;
}

bool LoadingScene::init(){
    if (!Layer::init())
        return false;
   
    
    _maxProgress=maxProgress;
    _progress=0;
    _showPercent=Label::createWithTTF("", "fonts/微软雅黑.ttf", 36);
    //this->addChild(_showPercent);
    _showPercent->setPosition(Vec2(480,100));
    
    this->addChild(_showPercent);
    auto sprite=Sprite::create(BG_z5_Light1);
    this->addChild(sprite,1);
    sprite->setPosition(SCREEN_CENTER);
    //进度对象
    _progressTimer=ProgressTimer::create(Sprite::create(BG_z5_Light));
    //设置类型为条状
    _progressTimer->setType(ProgressTimer::Type::BAR);
    //Director::getInstance()->getWinSize();
//    SCREEN.width*0.5
//    SCREEN.height*0.5
    //从 0 0 点开始
    _progressTimer->setMidpoint(Vec2(0,0));
    //
    _progressTimer->setBarChangeRate(Vec2(1,0));
    //设置位置
    _progressTimer->setPosition(SCREEN_CENTER);
    //设置当前进度的百分比
    _progressTimer->setPercentage(0);
    this->addChild(_progressTimer);
    return true
    ;

}
void LoadingScene::onEnterTransitionDidFinish(){
    
        Layer::onEnterTransitionDidFinish();
    
 this->loadResoureces();
}
void LoadingScene::loadResoureces(){
    //异步加载
    Director::getInstance()->getTextureCache()->addImageAsync(BG_EvilSky, CC_CALLBACK_1(LoadingScene::loadingCallBack, this));
//#define BG_EvilSky "map/BG_EvilSky.jpg"
    Director::getInstance()->getTextureCache()->addImageAsync(BG_Sky, CC_CALLBACK_1(LoadingScene::loadingCallBack, this));
//#define BG_Sky "map/BG_Sky.jpg"
    Director::getInstance()->getTextureCache()->addImageAsync(BG_z5_Light, CC_CALLBACK_1(LoadingScene::loadingCallBack, this));
//#define BG_z5_Light "map/BG_z5_Light.png"
    Director::getInstance()->getTextureCache()->addImageAsync(BG_z5_Light1, CC_CALLBACK_1(LoadingScene::loadingCallBack, this));
//#define BG_z5_Light1 "map/BG_z5_Light1.png"
    Director::getInstance()->getTextureCache()->addImageAsync(BG_z6_Screen1flr, CC_CALLBACK_1(LoadingScene::loadingCallBack, this));
//#define BG_z6_Screen1flr "map/BG_z6_Screen1flr.png"
    Director::getInstance()->getTextureCache()->addImageAsync(BG_z6_Screen2flr, CC_CALLBACK_1(LoadingScene::loadingCallBack, this));
//#define BG_z6_Screen2flr "map/BG_z6_Screen2flr.png"
    Director::getInstance()->getTextureCache()->addImageAsync(CloudForestWallGround, CC_CALLBACK_1(LoadingScene::loadingCallBack, this));
//#define CloudForestWallGround "map/CloudForestWallGround.png"
    Director::getInstance()->getTextureCache()->addImageAsync(ForegroundOjbects, CC_CALLBACK_1(LoadingScene::loadingCallBack, this));
//#define ForegroundOjbects "map/ForegroundOjbects.png"
    Director::getInstance()->getTextureCache()->addImageAsync(Sprite_JumpDashSmoke, CC_CALLBACK_1(LoadingScene::loadingCallBack, this));
//#define Sprite_JumpDashSmoke "Animation/Sprite_JumpDashSmoke.png"
    Director::getInstance()->getTextureCache()->addImageAsync(Sprite_Ninja, CC_CALLBACK_1(LoadingScene::loadingCallBack, this));
//#define Sprite_Ninja "Animation/Sprite_Ninja.png"
    Director::getInstance()->getTextureCache()->addImageAsync(Sprite_NinjaCloseSlash_v0, CC_CALLBACK_1(LoadingScene::loadingCallBack, this));
//#define Sprite_NinjaCloseSlash_v0 "Animation/Sprite_NinjaCloseSlash_v0.png"
    Director::getInstance()->getTextureCache()->addImageAsync(Sprite_Soldier1, CC_CALLBACK_1(LoadingScene::loadingCallBack, this));
//#define Sprite_Soldier1 "Animation/Sprite_Soldier1.png"
    Director::getInstance()->getTextureCache()->addImageAsync(Sprite_Soldier2, CC_CALLBACK_1(LoadingScene::loadingCallBack, this));
//#define Sprite_Soldier2 "Animation/Sprite_Soldier2.png"
    Director::getInstance()->getTextureCache()->addImageAsync(Sprite_Soldier3, CC_CALLBACK_1(LoadingScene::loadingCallBack, this));
//#define Sprite_Soldier3 "Animation/Sprite_Soldier3.png"
    Director::getInstance()->getTextureCache()->addImageAsync(Sprite_Speardeath_v0, CC_CALLBACK_1(LoadingScene::loadingCallBack, this));
//#define Sprite_Speardeath_v0 "Animation/Sprite_Speardeath_v0.png"
    Director::getInstance()->getTextureCache()->addImageAsync(Sprite_SpearSoldiers, CC_CALLBACK_1(LoadingScene::loadingCallBack, this));
//#define Sprite_SpearSoldiers "Animation/Sprite_SpearSoldiers.png"
}

void LoadingScene::loadingCallBack(Texture2D*texture){
    _progress+=1/_maxProgress*100;
    _progressTimer->setPercentage(_progress);
    //c++函数拼接字符串
    char buffer[100];
    sprintf(buffer, "加载 %1.2f%%",_progress);
    _showPercent->setString(buffer);
    if (100-_progress<0.01) {
        Director::getInstance()->replaceScene(TransitionFade::create(1, GameScene::create()));
    }

}